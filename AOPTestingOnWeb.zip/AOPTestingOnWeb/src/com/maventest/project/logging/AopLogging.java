package com.maventest.project.logging;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class AopLogging {

	@Before("excution(*com.maventest.project.save)")
	public void beforeAddingEmp(){
		System.out.println("Adding New Employee");
	}
	
	@After("")
	public void afterAddingEmp(){
		System.out.println("Successfully added new employee");
	}
}
